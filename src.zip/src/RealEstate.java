import java.util.Arrays;
import java.util.Scanner;

public class RealEstate{
    public static final int CREAT_ACCOUNT = 1;
    public static final int LOGIN = 2;
    public static final int EXIT = 3;
    private Employee[] employees;
    private Customer[] customers;

    public RealEstate() {
        this.employees = new Employee[0];
        this.customers = new Customer[0];
    }


    public void openingScreen() {
        Scanner scanner = new Scanner(System.in);
        int choice = 0;
        do {
            System.out.println("Hello Choose your action by type number: "
                    + "\n" + "1 - creat account"
                    + "\n" + "2 - login"
                    + "\n" + "3 - exit");
            choice = scanner.nextInt();
        } while (choice != 1 && choice != 2 && choice != 3);
        openingScreenAct(choice);
    }

    public void openingScreenAct(int choice) {
        switch (choice) {
            case CREAT_ACCOUNT:
                creatAccount();
                openingScreen();
                break;
            case LOGIN:
                if (login() == null){
                    System.out.println("Wrong details!");
                    openingScreen();
                }
                System.out.println(toString());
                break;
            case EXIT:
                break;
        }
    }

    public void creatAccount() {
        Scanner scanner = new Scanner(System.in);
        String firstName;
        String lastName;
        String userName;
        String password;
        int userType = userType();
        do {
            System.out.println("Enter your first name");
            firstName = scanner.nextLine();
        } while (digitInside(firstName) && firstName.equals(" "));
        do {
            System.out.println("Enter your last name: ");
            lastName = scanner.nextLine();
        } while (digitInside(lastName) && lastName.equals(" "));
        do {
            System.out.println("Enter wanted username: ");
            userName = scanner.nextLine();
        } while (userNameExists(userName,userType) && userName.equals(" "));
        do {
            System.out.println("Enter a password");
            password = scanner.nextLine();
        } while (password.length() <= 5);
        if (userType == 2) {
            String employeeType = employeeType();
            this.employees = (Employee[]) addToArray(employees,new Employee(firstName,lastName,userName,password,userType,employeeType));
        }
        else {
            String clubMember = userTypeAct(userType);
            this.customers = (Customer[]) addToArray(customers,new Customer(firstName,lastName,userName,password,userType,clubMember));
        }
    }

    public boolean digitInside(String s1) {
        boolean digitInside = false;
        for (int i = 0; i < s1.length(); i++) {
            if (Character.isDigit(s1.charAt(i))) {
                digitInside = true;
                break;
            }
        }
        return digitInside;
    }

    public boolean userNameExists(String userName, int userType) {
        boolean userNameExists = false;
        if (userType == 2) {
            for (Employee employee : employees) {
                if (employee.getFirstName().equals(userName)) {
                    userNameExists = true;
                    break;
                }
            }
        } else {
            for (Customer customer : customers) {
                if (customer.getFirstName().equals(userName)) {
                    userNameExists = true;
                    break;
                }
            }
        }
        return userNameExists;
    }

    public static int userType() {
        Scanner scanner = new Scanner(System.in);
        int userType = 0;
        do {
            System.out.println("Enter wanted user type: "
                    + "\n" + "1 - Customer user"
                    + "\n" + "2 - Employee user");
            userType = scanner.nextInt();
        } while (userType != 1 && userType != 2);
        return userType;
    }

    public String userTypeAct(int userType){
        Scanner scanner = new Scanner(System.in);
        String userTypeAct = "";
        int choice = 0;
        if (userType == 1) {
            userTypeAct = isClubMember(userType);
        }
        else {
            userTypeAct = employeeType();
        }
        return userTypeAct;
    }

    public static String employeeType() {
        Scanner scanner = new Scanner(System.in);
        int choice = 0;
        String employeeType = "";
        do {
            System.out.println("Enter your employee type :"
                    + "\n" + "1 - regular"
                    + "\n" + "2 - manager"
                    + "\n" + "2 - manager team");
            choice = scanner.nextInt();
        } while (choice != 1 && choice != 2 && choice != 3);
        switch (choice) {
            case 1 -> employeeType = "regular";
            case 2 -> employeeType = "manager";
            case 3 -> employeeType = "manager team";
        }
        return employeeType;
    }


    public String isClubMember(int userType){
        Scanner scanner = new Scanner(System.in);
        String isClubMember = "";
        int choice;
        do {
            System.out.println("Are you a club member?"
                    + "\n" + "1 - yes"
                    + "\n" + "2 - no");
            choice = scanner.nextInt();
        } while (choice != 1 && choice != 2);
        if (choice == 1){
            isClubMember = "yes";
        }
        else {
            isClubMember = "no";
        }
        return isClubMember;
    }

    public Object[] addToArray(Object[] oldArray, Object toAdd) {
        Object[] newArray = new Object[oldArray.length + 1];
        for (int i = 0; i < oldArray.length; i++) {
            newArray[i] = oldArray[i];
        }
        newArray[oldArray.length] = toAdd;
        newArray= Arrays.asList(newArray).toArray(oldArray);
        return newArray;
    }

    public User login(){
        Scanner scanner = new Scanner(System.in);
        boolean loginSuccessfully = false;
        String userName;
        String password;
        int userType;
        System.out.println("Enter username: ");
        userName = scanner.nextLine();
        System.out.println("Enter password: ");
        password = scanner.nextLine();
        System.out.println("Enter userType: ");
        userType = scanner.nextInt();
        return detailsCheck(userName, password, userType);
    }

    public User detailsCheck(String userName, String password, int userType) {
        User user = new User();
        boolean login = false;
        if (userType == 1) {
            for (int i = 0; i < customers.length; i++) {
                if (customers[i].getFirstName().equals(userName) && customers[i].getPassword().equals(password)) {
                        login = true;
                        user = customers[i];
                }
            }
        } else {
            for (int i = 0; i < employees.length; i++) {
                if (employees[i].getFirstName().equals(userName) && employees[i].getPassword().equals(password)) {
                        login = true;
                        user = employees[i];
                }
            }
        }
        return user;
    }
}

