public class Customer extends User{
    private String clubMember;

    public Customer(String firstName, String lastName, String userName, String password, int userType,String clubMember){
        User.firstName = firstName;
        User.lastName = lastName;
        this.userName = userName;
        this.password = password;
        this.userType = userType;
        this.clubMember = clubMember;

    }

    public String getClubMember(){
        return clubMember;
    }

    public static String getFullName(){
        return firstName + " " + lastName;
    }

    public  String toString(){
        String toString = " ";
        if (getClubMember().equals("yes")){
            toString = "hello" + getFullName() + "(vip)";
        }
        else {
            toString = "hello" + getFullName();
        }
        return toString;
    }


}