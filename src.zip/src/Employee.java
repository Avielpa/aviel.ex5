public class Employee extends User{
    String employeeType;


    public Employee(String firstName, String lastName, String userName, String password, int userType, String employeeType){
        User.firstName = firstName;
        User.lastName = lastName;
        this.userName = userName;
        this.password = password;
        this.userType = userType;
        this.employeeType = employeeType;
    }

    public String getEmployeeType() {
        return employeeType;
    }

    public static String getFullName(){
        return firstName + " " + lastName;
    }


    public  String toString() {
        return "hello"  + getFullName();
    }
}